<?php
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login/index.php');
    exit;
}

require_once 'data.php';

$config_file = __DIR__ . '/../config.php';
$expired_file = "";
$expired_date = "";
$license_key = "";
$wa_admin = "";

if (file_exists($config_file)) {
    include $config_file;
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_credentials') {
        $new_username = trim($_POST['new_username'] ?? '');
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (!$new_username && !$new_password) {
            $response = ['success' => false, 'message' => 'Isi minimal username atau password baru!'];
        } elseif ($new_password && $new_password !== $confirm_password) {
            $response = ['success' => false, 'message' => 'Password konfirmasi tidak cocok!'];
        } elseif ($new_password && strlen($new_password) < 6) {
            $response = ['success' => false, 'message' => 'Password minimal 6 karakter!'];
        } else {
            $data_content = "<?php\n";
            $data_content .= "// Admin Credentials\n";
            $data_content .= "\$admin_username = " . var_export($new_username ?: $admin_username, true) . ";\n";
            $data_content .= "\$admin_password = " . var_export($new_password ? password_hash($new_password, PASSWORD_DEFAULT) : $admin_password, true) . ";\n";
            $data_content .= "?>";
            
            if (file_put_contents(__DIR__ . '/data.php', $data_content)) {
                if ($new_username) {
                    $_SESSION['admin_username'] = $new_username;
                }
                $response = ['success' => true, 'message' => 'Kredensial berhasil diperbarui!'];
            } else {
                $response = ['success' => false, 'message' => 'Gagal memperbarui kredensial!'];
            }
        }
    } 
    elseif ($action === 'update_expired') {
        $new_expired_file = trim($_POST['expired_file'] ?? '');
        
        if (!$new_expired_file) {
            $response = ['success' => false, 'message' => 'Path file expired.php tidak boleh kosong!'];
        } else {
            $config_content = "<?php\n";
            $config_content .= "\$expired_file = " . var_export($new_expired_file, true) . ";\n";
            $config_content .= "\$expired_date = " . var_export($expired_date, true) . ";\n";
            $config_content .= "\$license_key = " . var_export($license_key, true) . ";\n";
            $config_content .= "\$wa_admin = " . var_export($wa_admin, true) . ";\n";
            $config_content .= "?>";
            
            if (file_put_contents($config_file, $config_content)) {
                $response = ['success' => true, 'message' => 'Path expired.php berhasil diperbarui!'];
                $expired_file = $new_expired_file;
            } else {
                $response = ['success' => false, 'message' => 'Gagal memperbarui config.php!'];
            }
        }
    }
    elseif ($action === 'update_settings') {
        $new_expired_date = trim($_POST['expired_date'] ?? '');
        $new_license_key = trim($_POST['license_key'] ?? '');
        $new_wa_admin = trim($_POST['wa_admin'] ?? '');
        
        if (!$new_expired_date && !$new_license_key && !$new_wa_admin) {
            $response = ['success' => false, 'message' => 'Isi minimal satu field!'];
        } else {
            $config_content = "<?php\n";
            $config_content .= "\$expired_file = " . var_export($expired_file, true) . ";\n";
            $config_content .= "\$expired_date = " . var_export($new_expired_date ?: $expired_date, true) . ";\n";
            $config_content .= "\$license_key = " . var_export($new_license_key ?: $license_key, true) . ";\n";
            $config_content .= "\$wa_admin = " . var_export($new_wa_admin ?: $wa_admin, true) . ";\n";
            $config_content .= "?>";
            
            if (file_put_contents($config_file, $config_content)) {
                $response = ['success' => true, 'message' => 'Konfigurasi berhasil diperbarui!'];
                $expired_date = $new_expired_date ?: $expired_date;
                $license_key = $new_license_key ?: $license_key;
                $wa_admin = $new_wa_admin ?: $wa_admin;
            } else {
                $response = ['success' => false, 'message' => 'Gagal memperbarui config.php!'];
            }
        }
    }
    elseif ($action === 'generate_license') {
        $segments = [];
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        
        for ($i = 0; $i < 4; $i++) {
            $segment = '';
            for ($j = 0; $j < 5; $j++) {
                $segment .= $chars[random_int(0, strlen($chars) - 1)];
            }
            $segments[] = $segment;
        }
        
        $new_license = implode('-', $segments);
        
        $config_content = "<?php\n";
        $config_content .= "\$expired_file = " . var_export($expired_file, true) . ";\n";
        $config_content .= "\$expired_date = " . var_export($expired_date, true) . ";\n";
        $config_content .= "\$license_key = " . var_export($new_license, true) . ";\n";
        $config_content .= "\$wa_admin = " . var_export($wa_admin, true) . ";\n";
        $config_content .= "?>";
        
        if (file_put_contents($config_file, $config_content)) {
            $response = ['success' => true, 'message' => 'License key baru berhasil digenerate!', 'license' => $new_license];
            $license_key = $new_license;
        } else {
            $response = ['success' => false, 'message' => 'Gagal generate license key!'];
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login/index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
        }
        
        .glass-card {
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(148, 163, 184, 0.1);
        }
        
        .input-glow:focus {
            box-shadow: 0 0 20px rgba(99, 102, 241, 0.3);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 min-h-screen">
    <div x-data="adminDashboard()" class="max-w-6xl mx-auto p-4 md:p-6">
        <div class="glass-card rounded-2xl shadow-2xl p-6 mb-6">
            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div class="flex items-center gap-4">
                    <div class="p-3 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl">
                        <i class="bi bi-shield-lock-fill text-white text-3xl"></i>
                    </div>
                    <div>
                        <h1 class="text-2xl md:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">
                            Admin Dashboard
                        </h1>
                        <p class="text-gray-400 text-sm mt-1">Kelola konfigurasi sistem</p>
                    </div>
                </div>
                <a href="?logout=1"
                   class="flex items-center justify-center gap-2 px-5 py-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl border border-red-500/30 transition-all">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>

        <div class="glass-card rounded-2xl shadow-xl p-6 mb-6">
            <div class="flex items-center gap-3">
                <div class="p-2 bg-indigo-500/20 rounded-lg">
                    <i class="bi bi-person-circle text-indigo-400 text-2xl"></i>
                </div>
                <div>
                    <p class="text-gray-400 text-sm">Login sebagai</p>
                    <p class="text-white font-semibold text-lg"><?php echo htmlspecialchars($_SESSION['admin_username']); ?></p>
                </div>
            </div>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            <div class="glass-card rounded-2xl shadow-xl p-6">
                <div class="flex items-center gap-3 mb-6">
                    <div class="p-2 bg-blue-500/20 rounded-lg">
                        <i class="bi bi-key-fill text-blue-400 text-xl"></i>
                    </div>
                    <h2 class="text-xl font-semibold text-gray-200">Update Data Login</h2>
                </div>

                <form @submit.prevent="updateCredentials" class="space-y-4">
                    <div>
                        <label class="block text-gray-400 text-sm mb-2">Username Baru</label>
                        <div class="relative">
                            <i class="bi bi-person-fill absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                            <input type="text" 
                                   x-model="credentials.username"
                                   class="w-full bg-slate-800/50 text-white pl-12 pr-4 py-3 rounded-xl border border-slate-700/50 focus:border-indigo-500 focus:outline-none input-glow transition-all"
                                   placeholder="Kosongkan jika tidak diubah">
                        </div>
                    </div>

                    <div>
                        <label class="block text-gray-400 text-sm mb-2">Password Baru</label>
                        <div class="relative">
                            <i class="bi bi-lock-fill absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                            <input :type="showPassword ? 'text' : 'password'" 
                                   x-model="credentials.password"
                                   class="w-full bg-slate-800/50 text-white pl-12 pr-12 py-3 rounded-xl border border-slate-700/50 focus:border-indigo-500 focus:outline-none input-glow transition-all"
                                   placeholder="Minimal 6 karakter">
                            <button type="button" @click="showPassword = !showPassword"
                                    class="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-indigo-400 transition-colors">
                                <i :class="showPassword ? 'bi-eye-slash-fill' : 'bi-eye-fill'"></i>
                            </button>
                        </div>
                    </div>

                    <div>
                        <label class="block text-gray-400 text-sm mb-2">Konfirmasi Password</label>
                        <div class="relative">
                            <i class="bi bi-lock-fill absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                            <input :type="showPassword ? 'text' : 'password'" 
                                   x-model="credentials.confirmPassword"
                                   class="w-full bg-slate-800/50 text-white pl-12 pr-4 py-3 rounded-xl border border-slate-700/50 focus:border-indigo-500 focus:outline-none input-glow transition-all"
                                   placeholder="Ulangi password baru">
                        </div>
                    </div>

                    <button type="submit" :disabled="loading"
                            class="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-3 rounded-xl transition-all shadow-lg">
                        <span x-show="!loading" class="flex items-center justify-center gap-2">
                            <i class="bi bi-check-circle"></i>
                            Simpan
                        </span>
                        <span x-show="loading" class="flex items-center justify-center gap-2">
                            <i class="bi bi-arrow-repeat animate-spin"></i>
                            Processing...
                        </span>
                    </button>
                </form>
            </div>

            
            <div class="glass-card rounded-2xl shadow-xl p-6">
                <div class="flex items-center gap-3 mb-6">
                    <div class="p-2 bg-orange-500/20 rounded-lg">
                        <i class="bi bi-file-earmark-code text-orange-400 text-xl"></i>
                    </div>
                    <h2 class="text-xl font-semibold text-gray-200">Path Expired.php</h2>
                </div>

                <form @submit.prevent="updateExpired" class="space-y-4">
                    <div>
                        <label class="block text-gray-400 text-sm mb-2">Path File Expired.php</label>
                        <div class="relative">
                            <i class="bi bi-folder2-open absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                            <input type="text" 
                                   x-model="expired.path"
                                   class="w-full bg-slate-800/50 text-white pl-12 pr-4 py-3 rounded-xl border border-slate-700/50 focus:border-orange-500 focus:outline-none input-glow transition-all"
                                   placeholder="Contoh: expired.php">
                        </div>
                        <p class="text-gray-500 text-xs mt-1.5">
                            <i class="bi bi-info-circle"></i> Path relatif dari root domain
                        </p>
                    </div>

                    <?php if ($expired_file): ?>
                    <div class="bg-slate-800/30 rounded-xl p-4 border border-slate-700/30">
                        <p class="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-2">Path Saat Ini:</p>
                        <div class="flex items-center gap-2 text-sm">
                            <i class="bi bi-check-circle-fill text-green-400"></i>
                            <span class="text-white font-mono"><?php echo htmlspecialchars($expired_file); ?></span>
                        </div>
                    </div>
                    <?php endif; ?>

                    <button type="submit" :disabled="loading"
                            class="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-3 rounded-xl transition-all shadow-lg">
                        <span x-show="!loading" class="flex items-center justify-center gap-2">
                            <i class="bi bi-file-earmark-code"></i>
                            Update Path
                        </span>
                        <span x-show="loading" class="flex items-center justify-center gap-2">
                            <i class="bi bi-arrow-repeat animate-spin"></i>
                            Processing...
                        </span>
                    </button>
                </form>
            </div>

            
            <div class="glass-card rounded-2xl shadow-xl p-6">
                <div class="flex items-center gap-3 mb-6">
                    <div class="p-2 bg-emerald-500/20 rounded-lg">
                        <i class="bi bi-gear-fill text-emerald-400 text-xl"></i>
                    </div>
                    <h2 class="text-xl font-semibold text-gray-200">Setting Website Expired</h2>
                </div>

                <form @submit.prevent="updateSettings" class="space-y-4">
                    <div>
                        <label class="block text-gray-400 text-sm mb-2">Tanggal Expired</label>
                        <div class="relative">
                            <i class="bi bi-calendar-event absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                            <input type="date" 
                                   x-model="settings.expiredDate"
                                   class="w-full bg-slate-800/50 text-white pl-12 pr-4 py-3 rounded-xl border border-slate-700/50 focus:border-emerald-500 focus:outline-none input-glow transition-all"
                                   placeholder="YYYY-MM-DD">
                        </div>
                    </div>

                    <div>
                        <label class="block text-gray-400 text-sm mb-2">License Key</label>
                        <div class="relative">
                            <i class="bi bi-key absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                            <input type="text" 
                                   x-model="settings.licenseKey"
                                   class="w-full bg-slate-800/50 text-white pl-12 pr-12 py-3 rounded-xl border border-slate-700/50 focus:border-emerald-500 focus:outline-none input-glow transition-all font-mono text-sm"
                                   placeholder="XXXXX-XXXXX-XXXXX-XXXXX">
                            <button type="button" @click="generateLicense()"
                                    class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-emerald-400 transition-colors"
                                    title="Generate Random">
                                <i class="bi bi-arrow-clockwise"></i>
                            </button>
                        </div>
                    </div>

                    <div>
                        <label class="block text-gray-400 text-sm mb-2">Nomor WA Admin</label>
                        <div class="relative">
                            <i class="bi bi-whatsapp absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                            <input type="text" 
                                   x-model="settings.waAdmin"
                                   class="w-full bg-slate-800/50 text-white pl-12 pr-4 py-3 rounded-xl border border-slate-700/50 focus:border-emerald-500 focus:outline-none input-glow transition-all"
                                   placeholder="628123456789">
                        </div>
                        <p class="text-gray-500 text-xs mt-1.5">
                            <i class="bi bi-info-circle"></i> Format: 628xxx (tanpa +)
                        </p>
                    </div>

                    <?php if ($expired_date || $license_key || $wa_admin): ?>
                    <div class="bg-slate-800/30 rounded-xl p-4 border border-slate-700/30 space-y-2">
                        <p class="text-gray-400 text-xs font-semibold uppercase tracking-wider mb-2">Data Saat Ini:</p>
                        <?php if ($expired_date): ?>
                        <div class="flex items-center gap-2 text-sm">
                            <i class="bi bi-calendar-check text-emerald-400"></i>
                            <span class="text-gray-400">Expired:</span>
                            <span class="text-white"><?php echo htmlspecialchars($expired_date); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($license_key): ?>
                        <div class="flex items-center gap-2 text-sm">
                            <i class="bi bi-key-fill text-emerald-400"></i>
                            <span class="text-gray-400">License:</span>
                            <span class="text-white font-mono text-xs"><?php echo htmlspecialchars($license_key); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if ($wa_admin): ?>
                        <div class="flex items-center gap-2 text-sm">
                            <i class="bi bi-whatsapp text-emerald-400"></i>
                            <span class="text-gray-400">WA:</span>
                            <span class="text-white"><?php echo htmlspecialchars($wa_admin); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <button type="submit" :disabled="loading"
                            class="w-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-3 rounded-xl transition-all shadow-lg">
                        <span x-show="!loading" class="flex items-center justify-center gap-2">
                            <i class="bi bi-check-circle"></i>
                            Update Settings
                        </span>
                        <span x-show="loading" class="flex items-center justify-center gap-2">
                            <i class="bi bi-arrow-repeat animate-spin"></i>
                            Processing...
                        </span>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        function adminDashboard() {
            return {
                loading: false,
                showPassword: false,
                credentials: {
                    username: '',
                    password: '',
                    confirmPassword: ''
                },
                expired: {
                    path: '<?php echo htmlspecialchars($expired_file); ?>'
                },
                settings: {
                    expiredDate: '<?php echo htmlspecialchars($expired_date); ?>',
                    licenseKey: '<?php echo htmlspecialchars($license_key); ?>',
                    waAdmin: '<?php echo htmlspecialchars($wa_admin); ?>'
                },
                
                async updateCredentials() {
                    this.loading = true;
                    
                    const formData = new FormData();
                    formData.append('action', 'update_credentials');
                    formData.append('new_username', this.credentials.username);
                    formData.append('new_password', this.credentials.password);
                    formData.append('confirm_password', this.credentials.confirmPassword);
                    
                    try {
                        const response = await fetch('', {
                            method: 'POST',
                            body: formData
                        });
                        
                        const result = await response.json();
                        
                        if (result.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: result.message,
                                background: '#1e293b',
                                color: '#fff',
                                confirmButtonColor: '#6366f1'
                            }).then(() => {
                                if (this.credentials.username) {
                                    location.reload();
                                } else {
                                    this.credentials = {
                                        username: '',
                                        password: '',
                                        confirmPassword: ''
                                    };
                                }
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal!',
                                text: result.message,
                                background: '#1e293b',
                                color: '#fff',
                                confirmButtonColor: '#ef4444'
                            });
                        }
                    } catch (error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Terjadi kesalahan pada server',
                            background: '#1e293b',
                            color: '#fff',
                            confirmButtonColor: '#ef4444'
                        });
                    } finally {
                        this.loading = false;
                    }
                },
                
                async updateExpired() {
                    this.loading = true;
                    
                    const formData = new FormData();
                    formData.append('action', 'update_expired');
                    formData.append('expired_file', this.expired.path);
                    
                    try {
                        const response = await fetch('', {
                            method: 'POST',
                            body: formData
                        });
                        
                        const result = await response.json();
                        
                        if (result.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: result.message,
                                background: '#1e293b',
                                color: '#fff',
                                confirmButtonColor: '#ea580c'
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal!',
                                text: result.message,
                                background: '#1e293b',
                                color: '#fff',
                                confirmButtonColor: '#ef4444'
                            });
                        }
                    } catch (error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Terjadi kesalahan pada server',
                            background: '#1e293b',
                            color: '#fff',
                            confirmButtonColor: '#ef4444'
                        });
                    } finally {
                        this.loading = false;
                    }
                },
                
                async updateSettings() {
                    this.loading = true;
                    
                    const formData = new FormData();
                    formData.append('action', 'update_settings');
                    formData.append('expired_date', this.settings.expiredDate);
                    formData.append('license_key', this.settings.licenseKey);
                    formData.append('wa_admin', this.settings.waAdmin);
                    
                    try {
                        const response = await fetch('', {
                            method: 'POST',
                            body: formData
                        });
                        
                        const result = await response.json();
                        
                        if (result.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: result.message,
                                background: '#1e293b',
                                color: '#fff',
                                confirmButtonColor: '#10b981'
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal!',
                                text: result.message,
                                background: '#1e293b',
                                color: '#fff',
                                confirmButtonColor: '#ef4444'
                            });
                        }
                    } catch (error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Terjadi kesalahan pada server',
                            background: '#1e293b',
                            color: '#fff',
                            confirmButtonColor: '#ef4444'
                        });
                    } finally {
                        this.loading = false;
                    }
                },
                
                async generateLicense() {
                    const formData = new FormData();
                    formData.append('action', 'generate_license');
                    
                    try {
                        const response = await fetch('', {
                            method: 'POST',
                            body: formData
                        });
                        
                        const result = await response.json();
                        
                        if (result.success) {
                            this.settings.licenseKey = result.license;
                            Swal.fire({
                                icon: 'success',
                                title: 'License Key Baru!',
                                text: result.license,
                                background: '#1e293b',
                                color: '#fff',
                                confirmButtonColor: '#10b981',
                                html: `<p class="text-gray-400 mb-2">License key baru telah digenerate:</p>
                                       <p class="text-xl font-mono text-emerald-400">${result.license}</p>
                                       <p class="text-gray-500 text-sm mt-2">Klik "Update Settings" untuk menyimpan</p>`
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal!',
                                text: result.message,
                                background: '#1e293b',
                                color: '#fff',
                                confirmButtonColor: '#ef4444'
                            });
                        }
                    } catch (error) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'Terjadi kesalahan pada server',
                            background: '#1e293b',
                            color: '#fff',
                            confirmButtonColor: '#ef4444'
                        });
                    }
                }
            }
        }
    </script>
</body>
</html>