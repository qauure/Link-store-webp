<?php
session_start();


if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: ../');
    exit;
}


$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../data.php';
    
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($username === $admin_username && password_verify($password, $admin_password)) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;
        header('Location: ../');
        exit;
    } else {
        $error = 'Username atau password salah!';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
        }
        
        .glass-card {
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(148, 163, 184, 0.1);
        }
        
        .input-glow:focus {
            box-shadow: 0 0 20px rgba(99, 102, 241, 0.3);
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        
        .animate-float {
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade-in {
            animation: fadeIn 0.6s ease-out;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 min-h-screen flex items-center justify-center p-4">
    <div x-data="{ showPassword: false }" class="max-w-md w-full animate-fade-in">
        <div class="glass-card rounded-2xl shadow-2xl p-8 md:p-10">
            
            <div class="text-center mb-8">
                <div class="inline-block p-4 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl shadow-lg mb-4 animate-float">
                    <i class="bi bi-shield-lock-fill text-white text-5xl"></i>
                </div>
                <h2 class="text-3xl md:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400 mb-2">
                    Admin Login
                </h2>
                <p class="text-gray-400">Masuk ke Dashboard Admin</p>
            </div>

            
            <?php if ($error): ?>
            <div class="bg-red-500/10 border border-red-500/30 rounded-xl p-4 mb-6 animate-fade-in">
                <div class="flex items-center gap-3">
                    <i class="bi bi-exclamation-circle-fill text-red-400 text-xl"></i>
                    <p class="text-red-400 text-sm"><?php echo htmlspecialchars($error); ?></p>
                </div>
            </div>
            <?php endif; ?>

            
            <form method="POST" class="space-y-5">
                <div>
                    <label class="block text-gray-400 mb-2 text-sm">Username</label>
                    <div class="relative">
                        <i class="bi bi-person-fill absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                        <input type="text" name="username" required
                               class="w-full bg-slate-800/50 text-white pl-12 pr-4 py-3 rounded-xl border border-slate-700/50 focus:border-indigo-500 focus:outline-none input-glow transition-all"
                               placeholder="Masukkan username"
                               autocomplete="username">
                    </div>
                </div>

                <div>
                    <label class="block text-gray-400 mb-2 text-sm">Password</label>
                    <div class="relative">
                        <i class="bi bi-lock-fill absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
                        <input :type="showPassword ? 'text' : 'password'" name="password" required
                               class="w-full bg-slate-800/50 text-white pl-12 pr-12 py-3 rounded-xl border border-slate-700/50 focus:border-indigo-500 focus:outline-none input-glow transition-all"
                               placeholder="Masukkan password"
                               autocomplete="current-password">
                        <button type="button" @click="showPassword = !showPassword"
                                class="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-indigo-400 transition-colors">
                            <i :class="showPassword ? 'bi-eye-slash-fill' : 'bi-eye-fill'"></i>
                        </button>
                    </div>
                </div>

                <button type="submit"
                        class="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-indigo-500/50 mt-6">
                    <span class="flex items-center justify-center gap-2">
                        <i class="bi bi-box-arrow-in-right"></i>
                        Masuk ke Dashboard
                    </span>
                </button>
            </form>

            
            <div class="mt-8 pt-6 border-t border-slate-700/50">
                <div class="flex items-center justify-center gap-2 text-gray-500 text-xs">
                    <i class="bi bi-shield-check"></i>
                    <span> Admin Access</span>
                </div>
            </div>
        </div>

        
        <div class="absolute top-10 left-10 w-20 h-20 bg-indigo-500/10 rounded-full blur-3xl -z-10"></div>
        <div class="absolute bottom-10 right-10 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl -z-10"></div>
    </div>
</body>
</html>
