<?php
// Admin Credentials
$admin_username = 'TOLOL JIR';
$admin_password = '$2y$10$DP0F1z43e3lk2DLq2ra/seA1TyC2AWOuxyIBYxAeDKpt.8t9NHIau';
?>