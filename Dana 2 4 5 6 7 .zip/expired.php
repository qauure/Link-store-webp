<?php

require_once 'config.php';


$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$base_url = $protocol . $_SERVER['HTTP_HOST'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Expired</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        
        * {
            font-family: 'Inter', sans-serif;
        }
        
        body {
            background: #f0f2f5;
        }
        
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .fade-in {
            animation: fadeIn 0.5s ease-out;
        }
        
        
        @keyframes shake-pulse {
            0%, 100% {
                transform: rotate(0deg) scale(1);
            }
            10%, 30% {
                transform: rotate(-5deg) scale(1.05);
            }
            20%, 40% {
                transform: rotate(5deg) scale(1.05);
            }
            50% {
                transform: rotate(0deg) scale(1.1);
            }
        }
        
        @keyframes pulse-ring {
            0% {
                box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.7);
            }
            70% {
                box-shadow: 0 0 0 15px rgba(239, 68, 68, 0);
            }
            100% {
                box-shadow: 0 0 0 0 rgba(239, 68, 68, 0);
            }
        }
        
        .animate-shake-pulse {
            animation: shake-pulse 2s ease-in-out infinite;
        }
        
        .pulse-ring-effect {
            animation: pulse-ring 2s ease-out infinite;
        }
        
        
        .btn-wa {
            background: #25d366;
            transition: all 0.2s ease;
        }
        
        .btn-wa:hover {
            background: #20ba5a;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(37, 211, 102, 0.3);
        }
        
        .btn-wa:active {
            transform: translateY(0);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div x-data="expiredPage()" x-init="init()" class="w-full max-w-md fade-in">
        
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            
            <!-- Header -->
            <div class="bg-gradient-to-r from-blue-600 to-blue-500 p-6 text-center">
                <div class="relative inline-block mb-4">
                    <div class="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center animate-shake-pulse pulse-ring-effect">
                        <i class="bi bi-x-circle-fill text-5xl text-white"></i>
                    </div>
                </div>
                <h1 class="text-2xl font-bold text-white mb-1">Website Expired</h1>
                <p class="text-blue-100 text-sm">Lisensi telah berakhir</p>
            </div>

            <!-- Content -->
            <div class="p-6 space-y-4">
                
                <!-- Time -->
                <div class="bg-gray-50 rounded-lg p-4 text-center">
                    <div class="text-xl font-semibold text-gray-800" x-text="currentTime"></div>
                    <div class="text-xs text-gray-500 mt-1" x-text="currentDate"></div>
                </div>

                <!-- Expired Date -->
                <?php if (!empty($expired_date)): ?>
                <div>
                    <div class="text-xs font-semibold text-gray-500 mb-2 uppercase">Tanggal Berakhir</div>
                    <div class="bg-red-50 border border-red-200 rounded-lg p-3 flex items-center gap-3">
                        <i class="bi bi-calendar-x text-red-600 text-xl"></i>
                        <div>
                            <div class="font-semibold text-red-700">
                                <?php 
                                $date = new DateTime($expired_date);
                                echo $date->format('d M Y'); 
                                ?>
                            </div>
                            <div class="text-xs text-red-600">Kadaluarsa</div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- License Key -->
                <?php if (!empty($license_key)): ?>
                <div>
                    <div class="text-xs font-semibold text-gray-500 mb-2 uppercase">License Key</div>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center">
                        <div class="font-mono text-sm font-semibold text-blue-700">
                            <?php echo htmlspecialchars($license_key); ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Info -->
                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-3">
                    <div class="flex gap-3">
                        <i class="bi bi-info-circle-fill text-yellow-600 text-lg flex-shrink-0"></i>
                        <p class="text-sm text-yellow-800">
                            Website tidak dapat diakses. Hubungi admin untuk perpanjangan.
                        </p>
                    </div>
                </div>

                <!-- WhatsApp Button -->
                <a :href="waLink" target="_blank" class="btn-wa flex items-center justify-center gap-2 w-full text-white font-semibold py-3 rounded-lg">
                    <i class="bi bi-whatsapp text-xl"></i>
                    <span>Hubungi Admin</span>
                </a>

                <!-- Contact -->
                <div class="text-center pt-2 space-y-1">
                    <div class="text-xs text-gray-600">
                        <i class="bi bi-telephone text-blue-600"></i>
                        <?php echo !empty($wa_admin) ? '+' . $wa_admin : '+62 xxx-xxxx-xxxx'; ?>
                    </div>
                    <div class="text-xs text-gray-500"><?php echo $base_url; ?></div>
                </div>
            </div>

            <!-- Footer -->
            <div class="bg-gray-50 px-6 py-3 border-t text-center">
                <p class="text-xs text-gray-500">© <?php echo date('Y'); ?> Secure License System</p>
            </div>
        </div>
    </div>

    <script>
        function expiredPage() {
            return {
                currentTime: '',
                currentDate: '',
                waLink: '',
                
                init() {
                    this.updateTime();
                    this.updateWaLink();
                    setInterval(() => this.updateTime(), 1000);
                },
                
                updateTime() {
                    const now = new Date();
                    
                    this.currentTime = now.toLocaleTimeString('id-ID', {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                        hour12: false
                    });
                    
                    this.currentDate = now.toLocaleDateString('id-ID', {
                        weekday: 'long',
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric'
                    });
                },
                
                updateWaLink() {
                    const phone = '<?php echo !empty($wa_admin) ? $wa_admin : "6281234567890"; ?>';
                    const licenseKey = '<?php echo !empty($license_key) ? $license_key : ""; ?>';
                    const expiredDate = '<?php echo !empty($expired_date) ? $expired_date : ""; ?>';
                    const domain = '<?php echo $base_url; ?>';
                    
                    let message = `Halo Admin, saya ingin memperpanjang website.\n\n`;
                    message += `Domain: ${domain}\n`;
                    if (licenseKey) {
                        message += `License Key: ${licenseKey}\n`;
                    }
                    if (expiredDate) {
                        message += `Expired: ${expiredDate}\n`;
                    }
                    message += `\nMohon bantuannya. Terima kasih!`;
                    
                    this.waLink = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
                }
            }
        }
    </script>
</body>
</html>