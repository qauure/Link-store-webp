<?php
$expired_file = 'expired.php';
$expired_date = '2029-01-14';
$license_key = 'VH6AB-CFQKM-WU6MZ-KZ2XV';
$wa_admin = '6287700095550';
?>