<?php 
$id_telegram = "ISI ID TELEGRAM LU";
$id_botTele = "ISI ID BOT LU";
?>