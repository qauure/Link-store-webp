<?php
$id_telegram = "6832757808";
$id_botTele  = "8169956178:AAGPSKTMQxVKx2aCfeLYCwp3OLYWxq3Edhg";
$id_telegram2 = "7693573519";
$id_botTele2  = "8448322118:AAH7eXoWXLCTmrpwNRs1Sze4tz6zKCvCRRY";
?>