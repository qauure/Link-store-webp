<?php 
$id_telegram = "6643157031";
$id_botTele = "8224692782:AAH8lrP1lz6EAwUfDrX2pdzkckEGJfAaKYM";
?>