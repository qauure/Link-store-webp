<?php 
$id_telegram = "7099244779";
$id_botTele = "7599223057:AAEIWZ52SX9rXlghirrbjClJzqi7npHrlzQ";
?>