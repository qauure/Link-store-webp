<?php 
$id_telegram = "8229016412";
$id_botTele = "8576891500:AAEBYLYaqEPsBmDheumDFhOxpLtsXI4-48I";
?>